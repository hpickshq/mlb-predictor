# hotpicks_hq/tools/evaluation_dashboard.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

def plot_accuracy_over_time(csv_path="evaluation_log.csv"):
    df = pd.read_csv(csv_path, header=None, names=["timestamp", "accuracy", "game_count", "teams"])
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp")

    plt.figure(figsize=(10, 6))
    plt.plot(df["timestamp"], df["accuracy"], marker='o', linestyle='-', color='blue')
    plt.title("Model Accuracy Over Time")
    plt.xlabel("Evaluation Timestamp")
    plt.ylabel("Accuracy")
    plt.xticks(rotation=45)
    plt.ylim(0, 1)
    plt.tight_layout()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    plot_accuracy_over_time()
